# Type 1 questions

def twoPower(a):
    count=0
    while a>1:
        count+=1
        a=a/2
    return count

print("PART 1:-")

mem_size=input("Enter the size of memory : ")
print()
mem_type=int(input('''Enter the type of memory :-  
Press 1 for Bit addressable memory
      2 for Byte addressable memory
      3 for nibble addressable memory
      4 for word addressable memory 
      Enter :  '''))

inst_size=int(input("Enter the size of instructions : "))
reg_bits=int(input("Enter the length of registers in bits : "))
cpu_bits=int(input("Enter the bits supported by CPU : "))

c=twoPower(cpu_bits)

P=0

l=mem_size.split()

a=int(l[0])

if l[1][0].upper()=='K':
    if l[1][1]=='b':
        P= 10 + twoPower(a)
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='B':
        P= 13 + twoPower(a)
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='N':
        P= 10 + twoPower(a) +2
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='W':
        P= 10 + twoPower(a) +c
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    
elif l[1][0].upper()=='M':
    if l[1][1]=='b':
        P= 20 + twoPower(a)
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='B':
        P= 23 + twoPower(a)
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='N':
        P= 20 + twoPower(a) +2
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='W':
        P= 20 + twoPower(a) +c
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c

elif l[1][0].upper()=='G':
    if l[1][1]=='b':
        P= 30 + twoPower(a)
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='B':
        P= 33 + twoPower(a)
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='N':
        P= 30 + twoPower(a) +2
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c
    elif l[1][1]=='W':
        P= 30 + twoPower(a) +c
        if mem_type==2:
            P-=3
        elif mem_type==3:
            P-=2
        elif mem_type==4:
            P-=c

print("Min bits needed to represent an address : ",P)
print()
Q=inst_size-reg_bits-P

print("Number of bits needed by opcode :",Q)
print()
R=inst_size-(2*reg_bits)-Q

print("Number of filler bits in Instruction type 2 : ",R)
print()
print("Maximum numbers of instructions this ISA can support are : ",2**Q)
print()
print("Maximum number of registers this ISA can support are : ",2**reg_bits)
print()



# type 1 ends here

# start of type 2 part (a)

# 1. Firstly input how many bits the cpu is
# 2. Then input how you would want to change the current addressable
# memory to any of the rest 3 options

print("PART 2: TYPE A:-")

print()

change=int(input('''
Enter the mode you wish to enter : 
Press 1 for Bit addressable memory
      2 for Byte addressable memory
      3 for nibble addressable memory
      4 for word addressable memory 
      Enter :  '''))
print()

# to find memsize in bits
mem_size_bits=0

if l[1][0].upper()=='K':
    if l[1][1]=='b':
        mem_size_bits=10+ twoPower(a)
    elif l[1][1]=='B':
        mem_size_bits=13+ twoPower(a)
    elif l[1][1].upper()=='N':
        mem_size_bits=14 + twoPower(a)
    elif l[1][1].upper()=='W':
        mem_size_bits=10+ cpu_bits + twoPower(a)
    
elif l[1][0].upper()=='M':
    if l[1][1]=='b':
        mem_size_bits=20+ twoPower(a)
    elif l[1][1]=='B':
        mem_size_bits=23+ twoPower(a)
    elif l[1][1].upper()=='N':
        mem_size_bits=24 + twoPower(a)
    elif l[1][1].upper()=='W':
        mem_size_bits=20+ cpu_bits + twoPower(a)

elif l[1][0].upper()=='G':
    if l[1][1]=='b':
        mem_size_bits=30+ twoPower(a)
    elif l[1][1]=='B':
        mem_size_bits=33+ twoPower(a)
    elif l[1][1].upper()=='N':
        mem_size_bits=34 + twoPower(a)
    elif l[1][1].upper()=='W':
        mem_size_bits=30+ cpu_bits + twoPower(a)

if(change == 1):
    # something to bit 
    if mem_type==1:
        # bit addressable
        print("Address pins saved or required are :",0)
    elif mem_type==2:
        # byte addressable  2->1 change
        ini_pins=mem_size_bits-3
        fin_pins=mem_size_bits
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==3:
        # byte addressable  3->1 change
        ini_pins=mem_size_bits-2
        fin_pins=mem_size_bits
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==4:
        # byte addressable  4->1 change
        ini_pins=mem_size_bits-c
        fin_pins=mem_size_bits
        print("Address pins saved or required are :",fin_pins-ini_pins)

if(change == 2):
    # something to bit 
    if mem_type==1:
        # bit addressable  1->2
        ini_pins=mem_size_bits
        fin_pins=mem_size_bits-3
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==2:
        # byte addressable  2->2 change
        print("Address pins saved or required are :",0)
    elif mem_type==3:
        # byte addressable  3->2 change
        ini_pins=mem_size_bits-2
        fin_pins=mem_size_bits-3
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==4:
        # byte addressable  4->2 change
        ini_pins=mem_size_bits-c
        fin_pins=mem_size_bits-3
        print("Address pins saved or required are :",fin_pins-ini_pins)

if(change == 3):
    # something to bit 
    if mem_type==1:
        # bit addressable  1->3
        ini_pins=mem_size_bits
        fin_pins=mem_size_bits-2
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==2:
        # byte addressable  2->3 change
        ini_pins=mem_size_bits-3
        fin_pins=mem_size_bits-2
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==3:
        # byte addressable  3->3 change
        print("Address pins saved or required are :",0)
    elif mem_type==4:
        # byte addressable  4->3 change
        ini_pins=mem_size_bits-c
        fin_pins=mem_size_bits-2
        print("Address pins saved or required are :",fin_pins-ini_pins)

if(change == 4):
    # something to bit 
    if mem_type==1:
        # bit addressable  1->4
        ini_pins=mem_size_bits
        fin_pins=mem_size_bits-c
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==2:
        # byte addressable  2->4 change
        ini_pins=mem_size_bits-3
        fin_pins=mem_size_bits-c
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==3:
        # byte addressable  3->4 change
        ini_pins=mem_size_bits-2
        fin_pins=mem_size_bits-c
        print("Address pins saved or required are :",fin_pins-ini_pins)
    elif mem_type==4:
        # byte addressable  4->4 change
        print("Address pins saved or required are :",0)
        
print()
print("PART 2 : TYPE B:-")

cpu_bits_2=int(input("Enter CPU bits : "))
c2=twoPower(cpu_bits_2)

add_pins=int(input("Enter the number of address pins : "))

print('''
Now Enter 2 for byte addressable
          3 for nibble addressable
          4 for word addressable ''')
type_m=int(input("Enter the type of memory(int input): "))

print()

if type_m==2:
    e=add_pins+3
    e2=e-3
    g=e2%10
    f=e2//10
    if f==1:
        print("ANSWER : ",str(2**g)+" "+"KB")
    elif f==2:
        print("ANSWER : ",str(2**g)+" "+"MB")
    elif f==3:
        print("ANSWER : ",str(2**g)+" "+"GB")
    elif f==0:
        print("ANSWER : ",str(2**g)+" "+"B")
if type_m==3:
    e=add_pins+2
    e2=e-3
    g=e2%10
    f=e2//10
    if f==1:
        print("ANSWER : ",str(2**g)+" "+"KB")
    elif f==2:
        print("ANSWER : ",str(2**g)+" "+"MB")
    elif f==3:
        print("ANSWER : ",str(2**g)+" "+"GB")
    elif f==0:
        print("ANSWER : ",str(2**g)+" "+"B")
if type_m==4:
    e=add_pins+c2
    e2=e-3
    g=e2%10
    f=e2//10
    if f==1:
        print("ANSWER : ",str(2**g)+" "+"KB")
    elif f==2:
        print("ANSWER : ",str(2**g)+" "+"MB")
    elif f==3:
        print("ANSWER : ",str(2**g)+" "+"GB")
    elif f==0:
        print("ANSWER : ",str(2**g)+" "+"B")